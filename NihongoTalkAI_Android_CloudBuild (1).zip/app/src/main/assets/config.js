window.NIHONGO_CONFIG = {
  workerUrl: "https://polished-rice-6e7b.ahtai51039.workers.dev/"
};
