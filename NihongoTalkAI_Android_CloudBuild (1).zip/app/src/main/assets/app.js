const chat = document.getElementById('chat');
const form = document.getElementById('form');
const input = document.getElementById('message');
const send = document.getElementById('send');
const history = [];

function addBubble(text, who) {
  const el = document.createElement('div');
  el.className = `bubble ${who}`;
  if (who === 'ai') {
    const tag = document.createElement('span');
    tag.className = 'who';
    tag.textContent = 'あ · NIHONGO AI';
    el.appendChild(tag);
    el.appendChild(document.createTextNode(text));
  } else {
    const tag = document.createElement('span');
    tag.className = 'who';
    tag.textContent = 'KAMU';
    el.appendChild(tag);
    el.appendChild(document.createTextNode(text));
  }
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
}
async function sendMessage(text) {
  const url = window.NIHONGO_CONFIG?.workerUrl;
  if (!url) {
    addBubble('Alamat server belum diatur. Hubungi pembuat aplikasi.', 'ai');
    return;
  }
  addBubble(text, 'user');
  history.push({role:'user', content:text});
  input.value = '';
  send.disabled = true;
  try {
    const response = await fetch(url, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({messages:history})
    });
    const raw = await response.text();
    let data;
    try { data = JSON.parse(raw); }
    catch { throw new Error('Balasan server bukan JSON. Periksa Worker.'); }
    if (!response.ok) throw new Error(data.error || `Server error ${response.status}`);
    const answer = data.reply || data.message || 'Maaf, server belum mengirim jawaban.';
    history.push({role:'assistant', content:answer});
    addBubble(answer, 'ai');
  } catch (err) {
    addBubble('Belum bisa terhubung ke AI: ' + err.message + '. Pastikan koneksi internet aktif dan Worker mengizinkan akses aplikasi.', 'ai');
  } finally {
    send.disabled = false;
    input.focus();
  }
}
form.addEventListener('submit', e => {
  e.preventDefault();
  const text = input.value.trim();
  if (text) sendMessage(text);
});
document.querySelectorAll('[data-prompt]').forEach(btn => {
  btn.addEventListener('click', () => sendMessage(btn.dataset.prompt));
});
input.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    form.requestSubmit();
  }
});
